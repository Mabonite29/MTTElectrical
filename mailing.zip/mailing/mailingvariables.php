<?php
    $mail_host = "smtp.gmail.com";
    $mail_port = "587";
    $mail_sender_email = ""; //sender
    $mail_sender_password = ""; //sender
    $mail_sender_name = "Website Form";
?>